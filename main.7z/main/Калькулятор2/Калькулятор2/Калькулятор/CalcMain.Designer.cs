﻿namespace Калькулятор
{
    partial class CalculatorMain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.DigitsPanel = new System.Windows.Forms.Panel();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.CurrentOp = new System.Windows.Forms.Label();
            this.PercentBtn = new System.Windows.Forms.Button();
            this.ClrAllBtn = new System.Windows.Forms.Button();
            this.ClearBtn = new System.Windows.Forms.Button();
            this.DivBtn = new System.Windows.Forms.Button();
            this.ResultBtn = new System.Windows.Forms.Button();
            this.PlusBtn = new System.Windows.Forms.Button();
            this.MinBtn = new System.Windows.Forms.Button();
            this.MultBtn = new System.Windows.Forms.Button();
            this.Drob = new System.Windows.Forms.Button();
            this.ZeroBtn = new System.Windows.Forms.Button();
            this.NineBtn = new System.Windows.Forms.Button();
            this.EightBtn = new System.Windows.Forms.Button();
            this.SevenBtn = new System.Windows.Forms.Button();
            this.SixBtn = new System.Windows.Forms.Button();
            this.FiveBtn = new System.Windows.Forms.Button();
            this.FourBtn = new System.Windows.Forms.Button();
            this.ThreeBtn = new System.Windows.Forms.Button();
            this.TwoBtn = new System.Windows.Forms.Button();
            this.OneBtn = new System.Windows.Forms.Button();
            this.CountPanel = new System.Windows.Forms.Panel();
            this.CountTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.DigitsPanel.SuspendLayout();
            this.CountPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // DigitsPanel
            // 
            this.DigitsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(33)))), ((int)(((byte)(36)))));
            this.DigitsPanel.Controls.Add(this.button4);
            this.DigitsPanel.Controls.Add(this.button3);
            this.DigitsPanel.Controls.Add(this.button2);
            this.DigitsPanel.Controls.Add(this.button1);
            this.DigitsPanel.Controls.Add(this.splitter1);
            this.DigitsPanel.Controls.Add(this.CurrentOp);
            this.DigitsPanel.Controls.Add(this.PercentBtn);
            this.DigitsPanel.Controls.Add(this.ClrAllBtn);
            this.DigitsPanel.Controls.Add(this.ClearBtn);
            this.DigitsPanel.Controls.Add(this.DivBtn);
            this.DigitsPanel.Controls.Add(this.ResultBtn);
            this.DigitsPanel.Controls.Add(this.PlusBtn);
            this.DigitsPanel.Controls.Add(this.MinBtn);
            this.DigitsPanel.Controls.Add(this.MultBtn);
            this.DigitsPanel.Controls.Add(this.Drob);
            this.DigitsPanel.Controls.Add(this.ZeroBtn);
            this.DigitsPanel.Controls.Add(this.NineBtn);
            this.DigitsPanel.Controls.Add(this.EightBtn);
            this.DigitsPanel.Controls.Add(this.SevenBtn);
            this.DigitsPanel.Controls.Add(this.SixBtn);
            this.DigitsPanel.Controls.Add(this.FiveBtn);
            this.DigitsPanel.Controls.Add(this.FourBtn);
            this.DigitsPanel.Controls.Add(this.ThreeBtn);
            this.DigitsPanel.Controls.Add(this.TwoBtn);
            this.DigitsPanel.Controls.Add(this.OneBtn);
            this.DigitsPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.DigitsPanel.Location = new System.Drawing.Point(0, 191);
            this.DigitsPanel.Margin = new System.Windows.Forms.Padding(2);
            this.DigitsPanel.Name = "DigitsPanel";
            this.DigitsPanel.Size = new System.Drawing.Size(476, 614);
            this.DigitsPanel.TabIndex = 0;
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 614);
            this.splitter1.TabIndex = 21;
            this.splitter1.TabStop = false;
            // 
            // CurrentOp
            // 
            this.CurrentOp.AutoSize = true;
            this.CurrentOp.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CurrentOp.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.CurrentOp.Location = new System.Drawing.Point(12, 30);
            this.CurrentOp.Name = "CurrentOp";
            this.CurrentOp.Size = new System.Drawing.Size(168, 20);
            this.CurrentOp.TabIndex = 2;
            this.CurrentOp.Text = "Ожидание ввода...";
            // 
            // PercentBtn
            // 
            this.PercentBtn.BackColor = System.Drawing.Color.OrangeRed;
            this.PercentBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.PercentBtn.FlatAppearance.BorderSize = 4;
            this.PercentBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PercentBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PercentBtn.ForeColor = System.Drawing.Color.White;
            this.PercentBtn.Location = new System.Drawing.Point(4, 72);
            this.PercentBtn.Margin = new System.Windows.Forms.Padding(2);
            this.PercentBtn.Name = "PercentBtn";
            this.PercentBtn.Size = new System.Drawing.Size(113, 85);
            this.PercentBtn.TabIndex = 19;
            this.PercentBtn.Text = "%";
            this.PercentBtn.UseVisualStyleBackColor = false;
            this.PercentBtn.Click += new System.EventHandler(this.Operator_click);
            // 
            // ClrAllBtn
            // 
            this.ClrAllBtn.BackColor = System.Drawing.Color.OrangeRed;
            this.ClrAllBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.ClrAllBtn.FlatAppearance.BorderSize = 4;
            this.ClrAllBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ClrAllBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ClrAllBtn.ForeColor = System.Drawing.Color.White;
            this.ClrAllBtn.Location = new System.Drawing.Point(122, 72);
            this.ClrAllBtn.Margin = new System.Windows.Forms.Padding(2);
            this.ClrAllBtn.Name = "ClrAllBtn";
            this.ClrAllBtn.Size = new System.Drawing.Size(113, 85);
            this.ClrAllBtn.TabIndex = 18;
            this.ClrAllBtn.Text = "CE";
            this.ClrAllBtn.UseVisualStyleBackColor = false;
            this.ClrAllBtn.Click += new System.EventHandler(this.Clear);
            // 
            // ClearBtn
            // 
            this.ClearBtn.BackColor = System.Drawing.Color.OrangeRed;
            this.ClearBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.ClearBtn.FlatAppearance.BorderSize = 4;
            this.ClearBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ClearBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ClearBtn.ForeColor = System.Drawing.Color.White;
            this.ClearBtn.Image = global::Калькулятор.Properties.Resources.icons8_стереть_символ_50;
            this.ClearBtn.Location = new System.Drawing.Point(240, 72);
            this.ClearBtn.Margin = new System.Windows.Forms.Padding(2);
            this.ClearBtn.Name = "ClearBtn";
            this.ClearBtn.Size = new System.Drawing.Size(113, 85);
            this.ClearBtn.TabIndex = 17;
            this.ClearBtn.UseVisualStyleBackColor = false;
            this.ClearBtn.Click += new System.EventHandler(this.DelOne);
            // 
            // DivBtn
            // 
            this.DivBtn.BackColor = System.Drawing.Color.OrangeRed;
            this.DivBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.DivBtn.FlatAppearance.BorderSize = 4;
            this.DivBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DivBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DivBtn.ForeColor = System.Drawing.Color.White;
            this.DivBtn.Location = new System.Drawing.Point(357, 72);
            this.DivBtn.Margin = new System.Windows.Forms.Padding(2);
            this.DivBtn.Name = "DivBtn";
            this.DivBtn.Size = new System.Drawing.Size(113, 85);
            this.DivBtn.TabIndex = 16;
            this.DivBtn.Text = "/";
            this.DivBtn.UseVisualStyleBackColor = false;
            this.DivBtn.Click += new System.EventHandler(this.Operator_click);
            // 
            // ResultBtn
            // 
            this.ResultBtn.BackColor = System.Drawing.Color.OrangeRed;
            this.ResultBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.ResultBtn.FlatAppearance.BorderSize = 4;
            this.ResultBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ResultBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ResultBtn.ForeColor = System.Drawing.Color.White;
            this.ResultBtn.Location = new System.Drawing.Point(358, 433);
            this.ResultBtn.Margin = new System.Windows.Forms.Padding(2);
            this.ResultBtn.Name = "ResultBtn";
            this.ResultBtn.Size = new System.Drawing.Size(113, 85);
            this.ResultBtn.TabIndex = 15;
            this.ResultBtn.Text = "=";
            this.ResultBtn.UseVisualStyleBackColor = false;
            this.ResultBtn.Click += new System.EventHandler(this.ResultBtn_Click);
            // 
            // PlusBtn
            // 
            this.PlusBtn.BackColor = System.Drawing.Color.OrangeRed;
            this.PlusBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.PlusBtn.FlatAppearance.BorderSize = 4;
            this.PlusBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PlusBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.PlusBtn.ForeColor = System.Drawing.Color.White;
            this.PlusBtn.Location = new System.Drawing.Point(358, 343);
            this.PlusBtn.Margin = new System.Windows.Forms.Padding(2);
            this.PlusBtn.Name = "PlusBtn";
            this.PlusBtn.Size = new System.Drawing.Size(113, 85);
            this.PlusBtn.TabIndex = 14;
            this.PlusBtn.Text = "+";
            this.PlusBtn.UseVisualStyleBackColor = false;
            this.PlusBtn.Click += new System.EventHandler(this.Operator_click);
            // 
            // MinBtn
            // 
            this.MinBtn.BackColor = System.Drawing.Color.OrangeRed;
            this.MinBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.MinBtn.FlatAppearance.BorderSize = 4;
            this.MinBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MinBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MinBtn.ForeColor = System.Drawing.Color.White;
            this.MinBtn.Location = new System.Drawing.Point(358, 252);
            this.MinBtn.Margin = new System.Windows.Forms.Padding(2);
            this.MinBtn.Name = "MinBtn";
            this.MinBtn.Size = new System.Drawing.Size(113, 85);
            this.MinBtn.TabIndex = 13;
            this.MinBtn.Text = "-";
            this.MinBtn.UseVisualStyleBackColor = false;
            this.MinBtn.Click += new System.EventHandler(this.Operator_click);
            // 
            // MultBtn
            // 
            this.MultBtn.BackColor = System.Drawing.Color.OrangeRed;
            this.MultBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.MultBtn.FlatAppearance.BorderSize = 4;
            this.MultBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MultBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MultBtn.ForeColor = System.Drawing.Color.White;
            this.MultBtn.Location = new System.Drawing.Point(358, 162);
            this.MultBtn.Margin = new System.Windows.Forms.Padding(2);
            this.MultBtn.Name = "MultBtn";
            this.MultBtn.Size = new System.Drawing.Size(113, 85);
            this.MultBtn.TabIndex = 12;
            this.MultBtn.Text = "*";
            this.MultBtn.UseVisualStyleBackColor = false;
            this.MultBtn.Click += new System.EventHandler(this.Operator_click);
            // 
            // Drob
            // 
            this.Drob.BackColor = System.Drawing.Color.OrangeRed;
            this.Drob.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.Drob.FlatAppearance.BorderSize = 4;
            this.Drob.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Drob.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Drob.ForeColor = System.Drawing.Color.White;
            this.Drob.Location = new System.Drawing.Point(240, 433);
            this.Drob.Margin = new System.Windows.Forms.Padding(2);
            this.Drob.Name = "Drob";
            this.Drob.Size = new System.Drawing.Size(113, 85);
            this.Drob.TabIndex = 10;
            this.Drob.Text = ",";
            this.Drob.UseVisualStyleBackColor = false;
            this.Drob.Click += new System.EventHandler(this.DrobBtn);
            // 
            // ZeroBtn
            // 
            this.ZeroBtn.BackColor = System.Drawing.Color.OrangeRed;
            this.ZeroBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.ZeroBtn.FlatAppearance.BorderSize = 4;
            this.ZeroBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ZeroBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ZeroBtn.ForeColor = System.Drawing.Color.White;
            this.ZeroBtn.Location = new System.Drawing.Point(122, 433);
            this.ZeroBtn.Margin = new System.Windows.Forms.Padding(2);
            this.ZeroBtn.Name = "ZeroBtn";
            this.ZeroBtn.Size = new System.Drawing.Size(113, 85);
            this.ZeroBtn.TabIndex = 9;
            this.ZeroBtn.Text = "0";
            this.ZeroBtn.UseVisualStyleBackColor = false;
            this.ZeroBtn.Click += new System.EventHandler(this.MultBtn_Click);
            // 
            // NineBtn
            // 
            this.NineBtn.BackColor = System.Drawing.Color.OrangeRed;
            this.NineBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.NineBtn.FlatAppearance.BorderSize = 4;
            this.NineBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NineBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NineBtn.ForeColor = System.Drawing.Color.White;
            this.NineBtn.Location = new System.Drawing.Point(240, 343);
            this.NineBtn.Margin = new System.Windows.Forms.Padding(2);
            this.NineBtn.Name = "NineBtn";
            this.NineBtn.Size = new System.Drawing.Size(113, 85);
            this.NineBtn.TabIndex = 8;
            this.NineBtn.Text = "9";
            this.NineBtn.UseVisualStyleBackColor = false;
            this.NineBtn.Click += new System.EventHandler(this.MultBtn_Click);
            // 
            // EightBtn
            // 
            this.EightBtn.BackColor = System.Drawing.Color.OrangeRed;
            this.EightBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.EightBtn.FlatAppearance.BorderSize = 4;
            this.EightBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.EightBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.EightBtn.ForeColor = System.Drawing.Color.White;
            this.EightBtn.Location = new System.Drawing.Point(122, 343);
            this.EightBtn.Margin = new System.Windows.Forms.Padding(2);
            this.EightBtn.Name = "EightBtn";
            this.EightBtn.Size = new System.Drawing.Size(113, 85);
            this.EightBtn.TabIndex = 7;
            this.EightBtn.Text = "8";
            this.EightBtn.UseVisualStyleBackColor = false;
            this.EightBtn.Click += new System.EventHandler(this.MultBtn_Click);
            // 
            // SevenBtn
            // 
            this.SevenBtn.BackColor = System.Drawing.Color.OrangeRed;
            this.SevenBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.SevenBtn.FlatAppearance.BorderSize = 4;
            this.SevenBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SevenBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SevenBtn.ForeColor = System.Drawing.Color.White;
            this.SevenBtn.Location = new System.Drawing.Point(4, 343);
            this.SevenBtn.Margin = new System.Windows.Forms.Padding(2);
            this.SevenBtn.Name = "SevenBtn";
            this.SevenBtn.Size = new System.Drawing.Size(113, 85);
            this.SevenBtn.TabIndex = 6;
            this.SevenBtn.Text = "7";
            this.SevenBtn.UseVisualStyleBackColor = false;
            this.SevenBtn.Click += new System.EventHandler(this.MultBtn_Click);
            // 
            // SixBtn
            // 
            this.SixBtn.BackColor = System.Drawing.Color.OrangeRed;
            this.SixBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.SixBtn.FlatAppearance.BorderSize = 4;
            this.SixBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SixBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SixBtn.ForeColor = System.Drawing.Color.White;
            this.SixBtn.Location = new System.Drawing.Point(240, 252);
            this.SixBtn.Margin = new System.Windows.Forms.Padding(2);
            this.SixBtn.Name = "SixBtn";
            this.SixBtn.Size = new System.Drawing.Size(113, 85);
            this.SixBtn.TabIndex = 5;
            this.SixBtn.Text = "6";
            this.SixBtn.UseVisualStyleBackColor = false;
            this.SixBtn.Click += new System.EventHandler(this.MultBtn_Click);
            // 
            // FiveBtn
            // 
            this.FiveBtn.BackColor = System.Drawing.Color.OrangeRed;
            this.FiveBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.FiveBtn.FlatAppearance.BorderSize = 4;
            this.FiveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FiveBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FiveBtn.ForeColor = System.Drawing.Color.White;
            this.FiveBtn.Location = new System.Drawing.Point(122, 252);
            this.FiveBtn.Margin = new System.Windows.Forms.Padding(2);
            this.FiveBtn.Name = "FiveBtn";
            this.FiveBtn.Size = new System.Drawing.Size(113, 85);
            this.FiveBtn.TabIndex = 4;
            this.FiveBtn.Text = "5";
            this.FiveBtn.UseVisualStyleBackColor = false;
            this.FiveBtn.Click += new System.EventHandler(this.MultBtn_Click);
            // 
            // FourBtn
            // 
            this.FourBtn.BackColor = System.Drawing.Color.OrangeRed;
            this.FourBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.FourBtn.FlatAppearance.BorderSize = 4;
            this.FourBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FourBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FourBtn.ForeColor = System.Drawing.Color.White;
            this.FourBtn.Location = new System.Drawing.Point(4, 252);
            this.FourBtn.Margin = new System.Windows.Forms.Padding(2);
            this.FourBtn.Name = "FourBtn";
            this.FourBtn.Size = new System.Drawing.Size(113, 85);
            this.FourBtn.TabIndex = 3;
            this.FourBtn.Text = "4";
            this.FourBtn.UseVisualStyleBackColor = false;
            this.FourBtn.Click += new System.EventHandler(this.MultBtn_Click);
            // 
            // ThreeBtn
            // 
            this.ThreeBtn.BackColor = System.Drawing.Color.OrangeRed;
            this.ThreeBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.ThreeBtn.FlatAppearance.BorderSize = 4;
            this.ThreeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ThreeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ThreeBtn.ForeColor = System.Drawing.Color.White;
            this.ThreeBtn.Location = new System.Drawing.Point(240, 162);
            this.ThreeBtn.Margin = new System.Windows.Forms.Padding(2);
            this.ThreeBtn.Name = "ThreeBtn";
            this.ThreeBtn.Size = new System.Drawing.Size(113, 85);
            this.ThreeBtn.TabIndex = 2;
            this.ThreeBtn.Text = "3";
            this.ThreeBtn.UseVisualStyleBackColor = false;
            this.ThreeBtn.Click += new System.EventHandler(this.MultBtn_Click);
            // 
            // TwoBtn
            // 
            this.TwoBtn.BackColor = System.Drawing.Color.OrangeRed;
            this.TwoBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.TwoBtn.FlatAppearance.BorderSize = 4;
            this.TwoBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TwoBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TwoBtn.ForeColor = System.Drawing.Color.White;
            this.TwoBtn.Location = new System.Drawing.Point(122, 162);
            this.TwoBtn.Margin = new System.Windows.Forms.Padding(2);
            this.TwoBtn.Name = "TwoBtn";
            this.TwoBtn.Size = new System.Drawing.Size(113, 85);
            this.TwoBtn.TabIndex = 1;
            this.TwoBtn.Text = "2";
            this.TwoBtn.UseVisualStyleBackColor = false;
            this.TwoBtn.Click += new System.EventHandler(this.MultBtn_Click);
            // 
            // OneBtn
            // 
            this.OneBtn.BackColor = System.Drawing.Color.OrangeRed;
            this.OneBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.OneBtn.FlatAppearance.BorderSize = 4;
            this.OneBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OneBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.OneBtn.ForeColor = System.Drawing.Color.White;
            this.OneBtn.Location = new System.Drawing.Point(4, 162);
            this.OneBtn.Margin = new System.Windows.Forms.Padding(2);
            this.OneBtn.Name = "OneBtn";
            this.OneBtn.Size = new System.Drawing.Size(113, 85);
            this.OneBtn.TabIndex = 0;
            this.OneBtn.Text = "1";
            this.OneBtn.UseVisualStyleBackColor = false;
            this.OneBtn.Click += new System.EventHandler(this.MultBtn_Click);
            // 
            // CountPanel
            // 
            this.CountPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(57)))), ((int)(((byte)(62)))));
            this.CountPanel.Controls.Add(this.CountTextBox);
            this.CountPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.CountPanel.Location = new System.Drawing.Point(0, 0);
            this.CountPanel.Margin = new System.Windows.Forms.Padding(2);
            this.CountPanel.Name = "CountPanel";
            this.CountPanel.Size = new System.Drawing.Size(476, 195);
            this.CountPanel.TabIndex = 1;
            // 
            // CountTextBox
            // 
            this.CountTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(57)))), ((int)(((byte)(62)))));
            this.CountTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.CountTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CountTextBox.ForeColor = System.Drawing.Color.White;
            this.CountTextBox.Location = new System.Drawing.Point(9, 21);
            this.CountTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.CountTextBox.Multiline = true;
            this.CountTextBox.Name = "CountTextBox";
            this.CountTextBox.ReadOnly = true;
            this.CountTextBox.Size = new System.Drawing.Size(462, 73);
            this.CountTextBox.TabIndex = 1;
            this.CountTextBox.Text = "0";
            this.CountTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.OrangeRed;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.button1.FlatAppearance.BorderSize = 4;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(7, 433);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 85);
            this.button1.TabIndex = 22;
            this.button1.Text = "Cos";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.OrangeRed;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.button2.FlatAppearance.BorderSize = 4;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(8, 522);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(109, 81);
            this.button2.TabIndex = 23;
            this.button2.Text = "Sin";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.OrangeRed;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.button3.FlatAppearance.BorderSize = 4;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(122, 522);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(113, 81);
            this.button3.TabIndex = 24;
            this.button3.Text = "Lg n";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.OrangeRed;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(0)))), ((int)(((byte)(179)))));
            this.button4.FlatAppearance.BorderSize = 4;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(241, 522);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(230, 81);
            this.button4.TabIndex = 25;
            this.button4.Text = "Log v";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // CalculatorMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(476, 805);
            this.Controls.Add(this.CountPanel);
            this.Controls.Add(this.DigitsPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "CalculatorMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Калькулятор";
            this.DigitsPanel.ResumeLayout(false);
            this.DigitsPanel.PerformLayout();
            this.CountPanel.ResumeLayout(false);
            this.CountPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel DigitsPanel;
        private System.Windows.Forms.Button OneBtn;
        private System.Windows.Forms.Button PercentBtn;
        private System.Windows.Forms.Button ClrAllBtn;
        private System.Windows.Forms.Button DivBtn;
        private System.Windows.Forms.Button ResultBtn;
        private System.Windows.Forms.Button PlusBtn;
        private System.Windows.Forms.Button MinBtn;
        private System.Windows.Forms.Button MultBtn;
        private System.Windows.Forms.Button Drob;
        private System.Windows.Forms.Button ZeroBtn;
        private System.Windows.Forms.Button NineBtn;
        private System.Windows.Forms.Button EightBtn;
        private System.Windows.Forms.Button SevenBtn;
        private System.Windows.Forms.Button SixBtn;
        private System.Windows.Forms.Button FiveBtn;
        private System.Windows.Forms.Button FourBtn;
        private System.Windows.Forms.Button ThreeBtn;
        private System.Windows.Forms.Button TwoBtn;
        private System.Windows.Forms.Panel CountPanel;
        private System.Windows.Forms.TextBox CountTextBox;
        private System.Windows.Forms.Label CurrentOp;
        private System.Windows.Forms.Button ClearBtn;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
    }
}

