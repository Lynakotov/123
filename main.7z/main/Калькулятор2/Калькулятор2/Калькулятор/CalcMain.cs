﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Калькулятор
{
    public partial class CalculatorMain : Form
    {
        public String strOperator = ""; // Значение выбранного действия
        public Double value = 0; // Значение вычисляемого числа
        public bool operatorPressed = false; // Выбрано ли действие
        public Double result = 0; // Результат вычисления

        public CalculatorMain()
        {
            InitializeComponent();
        }

        private void MultBtn_Click(object sender, EventArgs e) // Данное событие стоит у всех цифровых кнопок и отвечает за нажатие на них
        {
            Button Btn = (Button)sender; // Обработка кнопки, которая была нажата (цифры)

            if(CountTextBox.Text == "0" || operatorPressed) // Если в текстбоксе вычислений стоит 0 или был выбран оператор
            {
                CountTextBox.Text = ""; // Текст в текстбоксе вычислений стирается
                CountTextBox.Text = CountTextBox.Text + Btn.Text; // К тексту в текстбоксе вычислений добавляется текст с нажатой цифровой кнопки
                operatorPressed = false; // Оператор перестает быть выбранным
            }
            else // Иначе
            {
                CountTextBox.Text = CountTextBox.Text + Btn.Text; // К тексту в текстбоксе вычислений добавляется цифровое значение нажатой кнопки
            }
        }
        private void DrobBtn(object sender, EventArgs e) // Кнопка запятой (десятичной дроби)
        {
            CountTextBox.Text = CountTextBox.Text + ","; // К тексту в текстбоксе вычислений добавляется запятая (становиться десятичной дробью)
        }

        private void Operator_click(object sender, EventArgs e) // Нажатие на кнопку действия (оператора)
        {
            Button Btn = (Button)sender; // Обработка кнопки, которая была нажата (оператора)

            strOperator = Btn.Text; // К переменной действия (оператора) присвается значение нажатой кнопки действия (оператора)

            value = Double.Parse(CountTextBox.Text); // При нажатии будет браться текущий текст, которые преобразуется в тип double (для дальнейших вычислений)
            operatorPressed = true; // Текущий оператор выбран

            CurrentOp.Text = value + " " + strOperator; // К дополнительному тексбоксу добавляется числовое значение и выбранное действие (оператор)
        }

        private void ResultBtn_Click(object sender, EventArgs e) // Нажатие на кнопку "равно"
        {
            CurrentOp.Text = "Ожидание дополнительного ввода..."; // Значение текста дополнительного текстбокса
            operatorPressed = false; // Действие больше не выбрано

            switch (strOperator) // В зависимости от выбранного действия происходит различные вычисления
            {
                case "+": // Если текущее действие - сложение
                    result = value + Double.Parse(CountTextBox.Text); // Результат равен значению в текстбоксе, до выбора действия сложенному со значение после выбора действия
                    CountTextBox.Text = result.ToString(); // Значение текста в текстбоксе вычислений = результату сложения
                    break; // Окончание конструкции switch

                case "-": // Если текущее действие - вычитание
                    result = value - Double.Parse(CountTextBox.Text);
                    CountTextBox.Text = result.ToString();
                    break;

                case "*": // Если текущее действие - умножение
                    result = value * Double.Parse(CountTextBox.Text);
                    CountTextBox.Text = result.ToString();
                    break;

                case "/": // Если текущее действие - деление
                    if (Double.Parse(CountTextBox.Text) == 0)
                    {

                    }
                    else
                    {
                        result = value / Double.Parse(CountTextBox.Text);
                        CountTextBox.Text = result.ToString();
                    }
                    
                    break;
                
                case "%":
                    result = value / 100 * Double.Parse(CountTextBox.Text);
                    CountTextBox.Text = result.ToString();
                    break;
            }
        }

        private void Clear(object sender, EventArgs e) // Кнопка очистки
        {
            operatorPressed = false; // Действие больше не выбрано
            CountTextBox.Text = "0"; // Текст в текстбоксе вычислений = 0
            CurrentOp.Text = "Ожидание ввода..."; // Текст в дополнительном текстбоксе обнуляется
        }

        private void DelOne(object sender, EventArgs e) // Кнопка удаления одного символа
        {
            if (CountTextBox.Text.Length == 1) // Обработка ошибки. Если символов всего 1, а мы пытаемся его удалить
            {
                CountTextBox.Text = "0"; 
            }
            else // Если символы есть
            {
                CountTextBox.Text = CountTextBox.Text.Remove(CountTextBox.Text.Length - 1); // Текст в текстбоксе вычислений = такому же тексту, но без последнего символа
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Math.Cos(a);
        }
    }
}
